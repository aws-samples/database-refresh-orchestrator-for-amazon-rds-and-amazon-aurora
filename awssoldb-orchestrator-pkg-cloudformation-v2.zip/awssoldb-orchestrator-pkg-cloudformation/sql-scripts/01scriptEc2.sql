# NOTES FOR LAMBDA:
# Remove semicolons ; from the end of each line
# Don't write multi-line statements
# Use blanks lines if needed, they will be ignored
# Multiple DMLs are managed within a single transaction (one DML fails, the transaction is rolled back)

# NOTES FOR EC2:
# Put semicolons ; at the end of each line
# Use blanks lines if needed, they will be ignored

TRUNCATE TABLE mysqldbp.logs;
