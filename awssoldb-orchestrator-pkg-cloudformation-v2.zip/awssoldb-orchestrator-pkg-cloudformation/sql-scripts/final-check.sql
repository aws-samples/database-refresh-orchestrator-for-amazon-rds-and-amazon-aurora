## Please run the following statements in the RDS database instance mysqlinstp:

SELECT * FROM mysqldbp.books ORDER BY id;

SELECT * FROM mysqldbp.logs ORDER BY recordingdate;

SELECT * FROM mysqldbp.customers ORDER BY id;